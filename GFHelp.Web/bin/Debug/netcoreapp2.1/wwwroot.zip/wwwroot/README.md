# zui-admin
zui后台管理模板!
目前页面及插件较少，会在后续开发中慢慢完善。


![](https://gitee.com/uploads/images/2017/1202/174537_81f16e6d_1428616.png)
![](https://gitee.com/uploads/images/2017/1202/174547_e5a96d3f_1428616.png)